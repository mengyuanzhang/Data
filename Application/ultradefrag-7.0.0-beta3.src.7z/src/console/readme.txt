This directory contains getopt.c and getopt1.c files which are part 
of the GNU C Library. For detailed licensing information read the 
`Credits and License' chapter of the UltraDefrag Handbook. You should
have received a copy of it along with this program; if not, go to 
http://ultradefrag.sourceforge.net/handbook/Credits.html
