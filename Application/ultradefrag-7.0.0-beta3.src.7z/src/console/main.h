//////////////////////////////////////////////////////////////////////////
//
//  UltraDefrag - a powerful defragmentation tool for Windows NT.
//  Copyright (c) 2007-2015 Dmitri Arkhangelski (dmitriar@gmail.com).
//  Copyright (c) 2010-2013 Stefan Pendl (stefanpe@users.sourceforge.net).
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//////////////////////////////////////////////////////////////////////////

#ifndef _UDEFRAG_CONSOLE_MAIN_H_
#define _UDEFRAG_CONSOLE_MAIN_H_

// =======================================================================
//                               Headers
// =======================================================================

#include <wx/wxprec.h>

#ifndef WX_PRECOMP
#include <wx/wx.h>
#endif

#include <wx/cmdline.h>
#include <wx/dynlib.h>
#include <wx/filename.h>
#include <wx/thread.h>

#include <conio.h>

#if wxUSE_UNICODE
#define wxCharStringFmtSpec "%ls"
#else
#define wxCharStringFmtSpec "%hs"
#endif

#if defined(__GNUC__)
extern "C" {
HRESULT WINAPI URLDownloadToCacheFileW(
    /* LPUNKNOWN */ void *lpUnkcaller,
    LPCWSTR szURL,
    LPWSTR szFileName,
    DWORD cchFileName,
    DWORD dwReserved,
    /*IBindStatusCallback*/ void *pBSC
);
}
#endif

#include "../include/dbg.h"
#include "../include/version.h"
#include "../dll/zenwinx/zenwinx.h"
#include "../dll/udefrag/udefrag.h"

// =======================================================================
//                              Constants
// =======================================================================

#define USAGE_TRACKING_ACCOUNT_ID wxT("UA-15890458-1")
#define TEST_TRACKING_ACCOUNT_ID  wxT("UA-70148850-1")

#ifndef _WIN64
  #define TRACKING_ID wxT("console-x86")
#else
 #if defined(_IA64_)
  #define TRACKING_ID wxT("console-ia64")
 #else
  #define TRACKING_ID wxT("console-x64")
 #endif
#endif

// append html extension to the tracking id, for historical reasons
#define USAGE_TRACKING_PATH wxT("/appstat/") TRACKING_ID wxT(".html")

// append 0x00000000 to count test runs, for reports usability sake;
// crash cases will be listed below, so it would be easy to compare numbers
#define TEST_TRACKING_PATH  wxT("/appstat/test/") wxT(wxUD_ABOUT_VERSION) \
    wxT("/") TRACKING_ID wxT("/0x00000000")

#define GA_REQUEST(type) ga_request(type##_PATH, type##_ACCOUNT_ID)

// =======================================================================
//                          Macro definitions
// =======================================================================

/* sets text color only if -b option is not set */
#define color(c) { if(!g_use_default_colors) (void)SetConsoleTextAttribute(g_out,c); }

/* sets text color regardless of -b option */
#define force_color(c) { (void)SetConsoleTextAttribute(g_out,c); }

/* reliable version of _putch */
#define rputch(c) { char s[2]; s[0] = c; s[1] = 0; printf("%s",s); }

// =======================================================================
//                            Declarations
// =======================================================================

class Log: public wxLog {
public:
    Log()  { delete SetActiveTarget(this); };
    ~Log() { SetActiveTarget(NULL); };

    virtual void DoLog(wxLogLevel level,
        const wxChar *msg,time_t timestamp);
};

bool check_admin_rights(void);
bool parse_cmdline(int argc, char **argv);
void show_help(void);
void init_map(char letter);
void redraw_map(udefrag_progress_info *pi);
void destroy_map(void);
void clear_line(void);
void print_unicode(wchar_t *string);
void ga_request(const wxString& path, const wxString& id);

void attach_debugger(void);

// =======================================================================
//                           Global variables
// =======================================================================

extern bool g_analyze;
extern bool g_optimize;
extern bool g_quick_optimization;
extern bool g_optimize_mft;
extern bool g_all;
extern bool g_all_fixed;
extern bool g_list_volumes;
extern bool g_list_all;
extern bool g_repeat;
extern bool g_no_progress;
extern bool g_show_vol_info;
extern bool g_show_map;
extern bool g_use_default_colors;
extern bool g_use_entire_window;
extern bool g_help;
extern bool g_wait;
extern bool g_shellex;
extern bool g_folder;
extern bool g_folder_itself;

extern short g_map_border_color;
extern char g_map_symbol;
extern int g_map_rows;
extern int g_map_symbols_per_line;
extern int g_extra_lines;

extern wxArrayString *g_volumes;
extern wxArrayString *g_paths;

extern HANDLE g_out;
extern short g_default_color;

extern bool g_stop;

#endif /* _UDEFRAG_CONSOLE_MAIN_H_ */
