These scripts and binaries are used as UltraDefrag build tools.
