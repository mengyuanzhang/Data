#define VERSION 7,0,0,0 
#define VERSION2 "7, 0, 0, 0\0" 
#define VERSIONINTITLE "UltraDefrag 7.0.0 beta3" 
#define VERSIONINTITLE_PORTABLE "UltraDefrag 7.0.0 beta3 Portable" 
#define ABOUT_VERSION "Ultra Defragmenter version 7.0.0 beta3" 
#define wxUD_ABOUT_VERSION "7.0.0 beta3" 
