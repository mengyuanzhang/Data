#define DEBUG 1
#define VERSION "3.14.13"
#define ADATE   "02 February 2015"

#define APCUPSD_RELEASE VERSION

#ifndef APCUPSD_HOST
# define APCUPSD_HOST HOST
#endif
