#
# Regular cron jobs for the apcupsd package
#
0 4    * * *   root    apcupsd_maintenance
