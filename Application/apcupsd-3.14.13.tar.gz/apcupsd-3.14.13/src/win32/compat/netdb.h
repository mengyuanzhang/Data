// winsock2.h has gethostbyname
#include <winsock2.h>
